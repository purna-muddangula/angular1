import { Component, OnInit } from '@angular/core';

@Component({
  
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {
  rows=3;
  emp=[
    {id:101,fname:"purna",loc:"hyd",sal:4756.456,date:new Date(),gender:2},
    {id:102,fname:"prathyu",loc:"vja",sal:5867.765,date:new Date(),gender:2},
    {id:103,fname:"navya",loc:"vja",sal:7980.345,date:new Date(),gender:2},
    {id:104,fname:"dhanya",loc:"vja",sal:5768.765,date:new Date(),gender:2},
    {id:105,fname:"nandu",loc:"hyd",sal:4575.458,date:new Date(),gender:2},
    {id:106,fname:"sanju",loc:"pne",sal:4345.233,date:new Date(),gender:3}
  ]
  constructor() { }
  ngOnInit(): void {
  }
}

